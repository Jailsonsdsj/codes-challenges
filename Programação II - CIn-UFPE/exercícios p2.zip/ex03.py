#msg 1
tipo_var = "string"
qnd = "três"

print(f" Definir uma {tipo_var} com {qnd} aspas simples permite construir textos com quebra de linha automática.\n")

#msg 2
pi = 3.14159
print(f"  O número pi é aproximadamente {pi:.2f}\n ")

#mgs 3
frase = "Formação de Recursos Humanos Qualificados em Inteligência Artificial"
palavras = frase.split()
print(palavras)