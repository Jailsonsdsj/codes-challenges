import math


a = 2
b = 4
c = 8

result = ((a**2) + (3/4) * b * 987 * (c - (19**-7)/math.sqrt(0.5**3)))
print(result)