a = True
b = False

print((a or b) and (not(b) and a))